from flask import Flask, render_template, request, jsonify
from flask_socketio import SocketIO, emit
import json
import logging
import parser as twitch_parser
import os
import threading
import webbrowser
import sys
import time
import urllib.request


# Импортируем PyQt5
try:
    from PyQt5 import QtCore, QtWidgets, QtWebEngineWidgets, QtGui
    PYQT_AVAILABLE = True
except ImportError:
    PYQT_AVAILABLE = False
    print("⚠️ PyQt5 не установлен. Установите: pip install PyQt5 PyQtWebEngine")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'dev-secret-key'
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

config = {}
overlay_settings = {}

# Глобальные переменные
overlay_window = None
flask_thread = None
running = True
qt_app = None
browser_window = None


def load_config():
    global config
    try:
        with open('config.json', 'r') as f:
            config = json.load(f)
    except:
        config = {'channel': '', 'port': 8080}
        save_config()


def save_config():
    with open('config.json', 'w') as f:
        json.dump(config, f, indent=2)

def load_settings():
    global overlay_settings
    try:
        with open('settings.json', 'r') as f:
            overlay_settings = json.load(f)
            # Убеждаемся, что bgOpacity существует
            if 'bgOpacity' not in overlay_settings:
                overlay_settings['bgOpacity'] = 0.85
    except:
        overlay_settings = {
            'messageDuration': 10,
            'maxMessages': 20,
            'autoRemove': True,
            'showBroadcaster': True,
            'bgOpacity': 0.85,
            'customCSS': ''
        }
        save_settings()


def save_settings():
    with open('settings.json', 'w') as f:
        json.dump(overlay_settings, f, indent=2)


load_config()
load_settings()

# Передаем socketio в парсер
twitch_parser.set_socketio(socketio)


@app.route('/')
def dashboard():
    return render_template('dashboard.html',
                           config=config,
                           settings=overlay_settings)


@app.route('/overlay')
def overlay():
    return render_template('overlay.html', settings=overlay_settings)


@app.route('/api/config', methods=['GET', 'POST'])
def api_config():
    global config
    if request.method == 'GET':
        return jsonify(config)

    data = request.json
    config.update(data)
    save_config()

    if data.get('channel'):
        twitch_parser.stop_parsing()
        twitch_parser.start_parsing(config.get('channel', ''), socketio)

    return jsonify({'status': 'ok'})


@app.route('/api/settings', methods=['GET', 'POST'])
def api_settings():
    global overlay_settings
    if request.method == 'GET':
        return jsonify(overlay_settings)

    data = request.json

    # Обновляем настройки, сохраняя все значения
    overlay_settings.update(data)

    # Убеждаемся, что bgOpacity сохраняется корректно
    if 'bgOpacity' in data:
        # Преобразуем в float, сохраняем точное значение
        try:
            overlay_settings['bgOpacity'] = float(data['bgOpacity'])
        except:
            overlay_settings['bgOpacity'] = 0.85

    save_settings()
    socketio.emit('settings_updated', overlay_settings)
    return jsonify({'status': 'ok'})


@app.route('/api/status')
def api_status():
    status = twitch_parser.get_parsing_status()
    return jsonify({
        'running': status['running'],
        'messages': status['queue_size'],
        'debug': status['debug_messages']
    })


@app.route('/api/start')
def api_start():
    channel = config.get('channel', '')
    if not channel:
        return jsonify({'status': 'error', 'message': 'No channel'}), 400

    twitch_parser.start_parsing(channel, socketio)
    return jsonify({'status': 'ok'})


@app.route('/api/stop')
def api_stop():
    twitch_parser.stop_parsing()
    return jsonify({'status': 'ok'})


@socketio.on('connect')
def handle_connect():
    logger.info('🔌 Клиент подключился к WebSocket')
    emit('settings_updated', overlay_settings)
    status = twitch_parser.get_parsing_status()
    emit('status_update', status)


@socketio.on('disconnect')
def handle_disconnect():
    logger.info('🔌 Клиент отключился от WebSocket')


@socketio.on('preview_opacity')
def handle_preview_opacity(opacity):
    """Предварительный просмотр прозрачности"""
    emit('preview_opacity', opacity, broadcast=True)


@socketio.on('preview_css')
def handle_preview_css(css):
    """Предварительный просмотр CSS"""
    emit('preview_css', css, broadcast=True)


def cleanup_processes():
    """Очистка всех процессов при завершении"""
    global running, qt_app

    logger.info("🧹 Начинаем очистку процессов...")
    running = False

    # Останавливаем парсер
    try:
        twitch_parser.stop_parsing()
        logger.info("✅ Парсер остановлен")
    except Exception as e:
        logger.error(f"Ошибка остановки парсера: {e}")

    # Останавливаем SocketIO
    try:
        socketio.stop()
        logger.info("✅ SocketIO остановлен")
    except Exception as e:
        logger.error(f"Ошибка остановки SocketIO: {e}")

    # Закрываем PyQt приложение
    try:
        if PYQT_AVAILABLE and qt_app:
            qt_app.quit()
            logger.info("✅ PyQt закрыт")
    except Exception as e:
        logger.error(f"Ошибка закрытия PyQt: {e}")

    logger.info("✅ Очистка завершена")


class BrowserWindow(QtWidgets.QMainWindow):
    """Окно с встроенным браузером на PyQt5"""

    def __init__(self, url, port):
        super().__init__()
        self.url = url
        self.port = port
        self.init_ui()

    def init_ui(self):
        """Инициализация интерфейса"""
        self.setWindowTitle("Twitch Chat Overlay")
        self.setGeometry(100, 100, 450, 750)
        self.setMinimumSize(350, 500)
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1a1a1a;
            }
            QToolBar {
                background-color: #2b2b2b;
                border: none;
                padding: 5px;
                spacing: 5px;
            }
            QToolButton {
                background-color: transparent;
                color: white;
                font-size: 18px;
                padding: 5px 10px;
                border: none;
                border-radius: 4px;
            }
            QToolButton:hover {
                background-color: #3b3b3b;
            }
            QToolButton:pressed {
                background-color: #4b4b4b;
            }
            QLabel {
                color: white;
                font-size: 12px;
                padding: 5px;
            }
        """)

        # Создаем панель инструментов
        self.toolbar = self.addToolBar("Navigation")
        self.toolbar.setMovable(False)

        # Кнопка "Плюс" - открывает главную страницу
        self.plus_action = QtWidgets.QAction("+", self)
        self.plus_action.triggered.connect(self.open_dashboard)
        self.plus_action.setToolTip("Открыть панель управления")
        self.toolbar.addAction(self.plus_action)

        # Разделитель
        separator = QtWidgets.QWidget()
        separator.setFixedWidth(10)
        self.toolbar.addWidget(separator)

        # Кнопка перезагрузки
        self.reload_action = QtWidgets.QAction("⟳", self)
        self.reload_action.triggered.connect(self.reload_page)
        self.reload_action.setToolTip("Перезагрузить страницу")
        self.toolbar.addAction(self.reload_action)

        # Разделитель
        separator2 = QtWidgets.QWidget()
        separator2.setFixedWidth(10)
        self.toolbar.addWidget(separator2)

        # Информация о порте
        self.port_label = QtWidgets.QLabel(f"Порт: {self.port}")
        self.toolbar.addWidget(self.port_label)

        # Растягивающийся пробел
        spacer = QtWidgets.QWidget()
        spacer.setSizePolicy(
            QtWidgets.QSizePolicy.Expanding,
            QtWidgets.QSizePolicy.Expanding
        )
        self.toolbar.addWidget(spacer)

        # Индикатор статуса
        self.status_label = QtWidgets.QLabel("●")
        self.status_label.setStyleSheet("color: green; font-size: 16px;")
        self.status_label.setToolTip("Оверлей работает")
        self.toolbar.addWidget(self.status_label)

        # Создаем веб-виджет
        self.browser = QtWebEngineWidgets.QWebEngineView()
        self.browser.setUrl(QtCore.QUrl(self.url))

        # Настройка для работы с WebSocket
        settings = self.browser.settings()
        settings.setAttribute(
            QtWebEngineWidgets.QWebEngineSettings.JavascriptEnabled, True
        )
        settings.setAttribute(
            QtWebEngineWidgets.QWebEngineSettings.LocalStorageEnabled, True
        )
        settings.setAttribute(
            QtWebEngineWidgets.QWebEngineSettings.WebGLEnabled, True
        )

        # Подключаем обработчик загрузки страницы
        self.browser.loadFinished.connect(self.on_load_finished)

        self.setCentralWidget(self.browser)

    def open_dashboard(self):
        """Открывает главную страницу в браузере"""
        url = f"http://localhost:{self.port}"
        webbrowser.open(url)
        logger.info(f"🌐 Открыта панель управления: {url}")

    def reload_page(self):
        """Перезагружает страницу"""
        self.browser.reload()
        self.status_label.setStyleSheet("color: yellow; font-size: 16px;")
        self.status_label.setToolTip("Перезагрузка...")
        logger.info("🔄 Перезагрузка страницы")

    def on_load_finished(self, success):
        """Обработчик завершения загрузки страницы"""
        if success:
            self.status_label.setStyleSheet("color: green; font-size: 16px;")
            self.status_label.setToolTip("Страница загружена")
            logger.info("✅ Страница загружена")
        else:
            self.status_label.setStyleSheet("color: red; font-size: 16px;")
            self.status_label.setToolTip("Ошибка загрузки")
            logger.error("❌ Ошибка загрузки страницы")

    def closeEvent(self, event):
        """Обработчик закрытия окна"""
        logger.info("🔄 Закрытие браузера...")
        cleanup_processes()
        event.accept()


class OverlayWindow:
    def __init__(self):
        self.port = self.get_port()

        # Если PyQt доступен, запускаем встроенный браузер
        if PYQT_AVAILABLE:
            self.run_pyqt()
        else:
            # Иначе используем Tkinter с кнопкой для открытия в браузере
            self.run_tkinter()

    def get_port(self):
        try:
            with open('config.json', 'r') as f:
                config = json.load(f)
                return config.get('port', 8080)
        except:
            return 8080

    def run_pyqt(self):
        """Запускает PyQt5 с встроенным браузером"""
        global qt_app, browser_window

        # Проверяем доступность сервера
        try:
            urllib.request.urlopen(f"http://localhost:{self.port}", timeout=2)
            server_ok = True
        except:
            server_ok = False

        if not server_ok:
            logger.error("❌ Сервер не запущен!")
            self.run_tkinter()
            return

        # Создаем QApplication
        qt_app = QtWidgets.QApplication.instance()
        if not qt_app:
            qt_app = QtWidgets.QApplication(sys.argv)

        # Создаем окно с браузером
        url = f"http://localhost:{self.port}/overlay"
        browser_window = BrowserWindow(url, self.port)
        browser_window.show()

        logger.info(f"✅ Оверлей загружен в PyQt5: {url}")

        # Запускаем цикл событий
        try:
            qt_app.exec_()
        except Exception as e:
            logger.error(f"Ошибка PyQt: {e}")
        finally:
            cleanup_processes()

    def run_tkinter(self):
        """Запускает Tkinter с кнопкой (альтернативный вариант)"""
        import tkinter as tk
        from tkinter import ttk

        self.root = tk.Tk()
        self.root.title("Twitch Chat Overlay")
        self.root.geometry("500x450")
        self.root.configure(bg='#1a1a1a')
        self.root.resizable(False, False)

        # Заголовок
        title = tk.Label(
            self.root,
            text="🎮 Twitch Chat Overlay",
            font=('Arial', 18, 'bold'),
            bg='#1a1a1a',
            fg='white'
        )
        title.pack(pady=20)

        # Статус
        try:
            urllib.request.urlopen(f"http://localhost:{self.port}", timeout=2)
            status_text = "✅ Сервер запущен"
            status_color = '#00ff00'
        except:
            status_text = "❌ Сервер не запущен"
            status_color = '#ff4444'

        status = tk.Label(
            self.root,
            text=status_text,
            font=('Arial', 12),
            bg='#1a1a1a',
            fg=status_color
        )
        status.pack(pady=10)

        # Информация
        info = tk.Label(
            self.root,
            text=f"Порт: {self.port}\n\n"
                 "Для просмотра оверлея откройте в браузере:",
            font=('Arial', 10),
            bg='#1a1a1a',
            fg='#888888'
        )
        info.pack(pady=10)

        # URL
        url_text = f"http://localhost:{self.port}/overlay"
        url_label = tk.Label(
            self.root,
            text=url_text,
            font=('Arial', 12, 'bold'),
            bg='#1a1a1a',
            fg='#9147ff',
            cursor='hand2'
        )
        url_label.pack(pady=5)
        url_label.bind('<Button-1>', lambda e: webbrowser.open(url_text))

        # Кнопка открытия в браузере
        open_btn = tk.Button(
            self.root,
            text="🌐 Открыть в браузере",
            command=lambda: webbrowser.open(url_text),
            bg='#9147ff',
            fg='white',
            font=('Arial', 12),
            padx=20,
            pady=10,
            cursor='hand2',
            relief='flat',
            borderwidth=0
        )
        open_btn.pack(pady=15)

        # Кнопка открытия панели управления
        dashboard_btn = tk.Button(
            self.root,
            text="➕ Открыть панель управления",
            command=lambda: webbrowser.open(f"http://localhost:{self.port}"),
            bg='#2b2b2b',
            fg='white',
            font=('Arial', 11),
            padx=20,
            pady=8,
            cursor='hand2',
            relief='flat',
            borderwidth=0
        )
        dashboard_btn.pack(pady=5)

        # Кнопка открытия в PyQt (если доступен)
        if PYQT_AVAILABLE:
            pyqt_btn = tk.Button(
                self.root,
                text="📱 Открыть во встроенном браузере",
                command=self.restart_with_pyqt,
                bg='#3b3b3b',
                fg='white',
                font=('Arial', 10),
                padx=20,
                pady=8,
                cursor='hand2',
                relief='flat',
                borderwidth=0
            )
            pyqt_btn.pack(pady=5)

        # Инструкция по установке PyQt
        if not PYQT_AVAILABLE:
            install_label = tk.Label(
                self.root,
                text="Для встроенного браузера установите:\npip install PyQt5 PyQtWebEngine",
                font=('Arial', 8),
                bg='#1a1a1a',
                fg='#666666'
            )
            install_label.pack(pady=10)

        # Разделитель
        separator = tk.Frame(self.root, height=1, bg='#2b2b2b')
        separator.pack(fill=tk.X, pady=20, padx=20)

        # Нижняя информация
        footer = tk.Label(
            self.root,
            text="💡 Нажмите на ссылку, чтобы открыть в браузере",
            font=('Arial', 8),
            bg='#1a1a1a',
            fg='#666666'
        )
        footer.pack(pady=5)

        # Обработчик закрытия
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

        # Запускаем Tkinter
        try:
            self.root.mainloop()
        except Exception as e:
            logger.error(f"Ошибка Tkinter: {e}")
        finally:
            cleanup_processes()

    def restart_with_pyqt(self):
        """Перезапускает приложение с PyQt5"""
        if hasattr(self, 'root') and self.root:
            self.root.destroy()
        self.run_pyqt()

    def on_closing(self):
        """Обработчик закрытия Tkinter"""
        logger.info("🔄 Закрытие приложения...")
        if hasattr(self, 'root') and self.root:
            self.root.quit()
            self.root.destroy()
        cleanup_processes()
        try:
            os._exit(0)
        except:
            pass


def start_overlay_gui():
    """Запускает GUI оверлея"""
    global overlay_window
    overlay_window = OverlayWindow()


def run_flask():
    """Запускает Flask сервер в отдельном потоке"""
    try:
        port = config.get('port', 8080)
        socketio.run(app, host='0.0.0.0', port=port, debug=False, allow_unsafe_werkzeug=True)
    except Exception as e:
        logger.error(f"Flask error: {e}")


if __name__ == '__main__':
    port = config.get('port', 8080)
    logger.info(f'🚀 Server running on http://localhost:{port}')
    logger.info(f'📺 Overlay: http://localhost:{port}/overlay')

    # Запускаем Flask в отдельном потоке
    flask_thread = threading.Thread(target=run_flask, daemon=True)
    flask_thread.start()

    # Даем время на запуск Flask
    time.sleep(2)

    # Запускаем GUI в главном потоке
    start_overlay_gui()