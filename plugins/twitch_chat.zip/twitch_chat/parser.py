import threading
import queue
import time
import re
import logging
import os
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

logger = logging.getLogger(__name__)

message_queue = queue.Queue()
parsing_running = False
driver = None
driver_lock = threading.Lock()
debug_messages_list = []
_socketio = None

# PID файл для защиты от двойного запуска
PID_FILE = '/tmp/twitch_parser.pid'


def check_pid_file():
    """Проверяет, не запущен ли уже парсер"""
    try:
        with open(PID_FILE, 'r') as f:
            old_pid = int(f.read().strip())
            # Проверяем, жив ли процесс
            try:
                os.kill(old_pid, 0)
                return True  # Процесс жив
            except OSError:
                return False  # Процесс мертв
    except:
        return False


def write_pid_file():
    """Записывает PID текущего процесса"""
    try:
        with open(PID_FILE, 'w') as f:
            f.write(str(os.getpid()))
        return True
    except Exception as e:
        logger.error(f"Ошибка записи PID файла: {e}")
        return False


def remove_pid_file():
    """Удаляет PID файл"""
    try:
        if os.path.exists(PID_FILE):
            os.remove(PID_FILE)
    except Exception as e:
        logger.error(f"Ошибка удаления PID файла: {e}")


def set_socketio(socketio):
    global _socketio
    _socketio = socketio
    logger.info("✅ SocketIO установлен в парсер")


def init_driver():
    global driver
    with driver_lock:
        if driver is not None:
            return driver

        logger.info("🛠 Инициализация Chrome драйвера...")
        chrome_options = Options()
        chrome_options.add_argument("--headless=new")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--window-size=1920,1080")
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option('useAutomationExtension', False)
        chrome_options.add_argument(
            "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=chrome_options)
        driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        logger.info("✅ Chrome драйвер инициализирован")
        return driver


def get_message_text(msg_element, username):
    try:
        js_script = """
            var element = arguments[0];
            var username = arguments[1];

            var fullText = element.textContent || element.innerText || '';
            var lines = fullText.split('\\n').map(function(line) { return line.trim(); });

            for (var i = 0; i < lines.length; i++) {
                var line = lines[i];
                if (line.includes('Время') || line.match(/^\\d{2}:\\d{2}/)) continue;
                if (!line) continue;
                return line;
            }

            return '';
        """
        text = driver.execute_script(js_script, msg_element, username)
        if text and text.strip():
            return text.strip()
    except Exception as e:
        logger.error(f"❌ Ошибка JS: {e}")
    return None


def clean_message(text, username):
    if not text:
        return ""
    pattern = re.compile(re.escape(username), re.IGNORECASE)
    cleaned = pattern.sub('', text).strip()
    if cleaned.startswith(':'):
        cleaned = cleaned[1:].strip()
    elif cleaned.startswith('：'):
        cleaned = cleaned[1:].strip()
    return cleaned.lstrip()


def get_user_avatar(msg_element):
    try:
        avatar_elem = msg_element.find_element(By.CSS_SELECTOR, "img[data-a-target='chat-avatar']")
        if avatar_elem:
            src = avatar_elem.get_attribute("src")
            if src:
                src = re.sub(r'-\d+x\d+\.', '-300x300.', src)
                return src
    except:
        pass
    try:
        avatar_elem = msg_element.find_element(By.CSS_SELECTOR, ".tw-avatar img")
        if avatar_elem:
            src = avatar_elem.get_attribute("src")
            if src:
                src = re.sub(r'-\d+x\d+\.', '-300x300.', src)
                return src
    except:
        pass
    return None


def start_parsing(channel, socketio=None):
    global parsing_running, _socketio

    # Проверка на двойной запуск
    if check_pid_file():
        logger.warning("⚠️ Парсер уже запущен в другом процессе!")
        return

    if parsing_running:
        logger.warning("⚠️ Парсинг уже запущен")
        return

    if not channel:
        logger.error("❌ Канал не указан")
        return

    if socketio:
        _socketio = socketio

    logger.info(f"🔄 Запуск парсинга для канала: {channel}")

    def run_parser():
        global parsing_running, driver, debug_messages_list, _socketio

        # Записываем PID
        if not write_pid_file():
            logger.error("❌ Не удалось записать PID файл")
            return

        try:
            driver = init_driver()

            url = f"https://www.twitch.tv/{channel}"
            logger.info(f"📡 ОТКРЫВАЮ СТРАНИЦУ: {url}")
            driver.get(url)
            logger.info("⏳ Ожидание загрузки страницы 5 секунд...")
            time.sleep(5)
            logger.info("✅ СТРАНИЦА ЗАГРУЖЕНА")

            try:
                close_btn = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, "[data-a-target='modal-close-button']"))
                )
                close_btn.click()
                logger.info("✅ Модальное окно закрыто")
                time.sleep(1)
            except:
                pass

            try:
                cookie_btn = driver.find_element(By.CSS_SELECTOR, "[data-a-target='consent-banner-accept']")
                cookie_btn.click()
                logger.info("✅ Cookie приняты")
                time.sleep(1)
            except:
                pass

            driver.execute_script("window.scrollBy(0, 300);")
            time.sleep(2)

            logger.info(f"✅ ПАРСЕР ЗАПУЩЕН ДЛЯ КАНАЛА {channel}")
            parsing_running = True

            seen_messages = set()
            message_counter = 0
            last_message_count = 0
            loop_count = 0
            parse_interval = 2

            while parsing_running:
                loop_count += 1
                try:
                    messages = driver.find_elements(By.CSS_SELECTOR, "[data-a-target='chat-line-message']")

                    if messages:
                        if len(messages) != last_message_count:
                            logger.info(f"📊 НАЙДЕНО СООБЩЕНИЙ: {len(messages)} (было: {last_message_count})")
                            last_message_count = len(messages)

                        for msg in messages:
                            try:
                                username = msg.get_attribute("data-a-user")
                                if not username:
                                    continue

                                raw_message = get_message_text(msg, username)
                                if not raw_message:
                                    continue

                                message = clean_message(raw_message, username)
                                if not message:
                                    continue

                                msg_id = f"{username}_{message}"
                                if msg_id in seen_messages:
                                    continue

                                timestamp = datetime.now().strftime("%H:%M")
                                try:
                                    aria_label = msg.get_attribute("aria-label")
                                    if aria_label:
                                        match = re.search(r"(\d{2}:\d{2})", aria_label)
                                        if match:
                                            timestamp = match.group(1)
                                except:
                                    pass

                                avatar = get_user_avatar(msg)

                                is_broadcaster = False
                                try:
                                    broadcaster_badges = msg.find_elements(By.CSS_SELECTOR,
                                                                           "img[alt='Владелец канала']")
                                    if broadcaster_badges:
                                        is_broadcaster = True
                                except:
                                    pass

                                message_data = {
                                    "username": username,
                                    "message": message,
                                    "timestamp": timestamp,
                                    "avatar": avatar,
                                    "is_broadcaster": is_broadcaster,
                                    "full_timestamp": datetime.now().isoformat()
                                }

                                message_queue.put(message_data)
                                seen_messages.add(msg_id)
                                message_counter += 1

                                debug_messages_list.append(message_data)
                                if len(debug_messages_list) > 50:
                                    debug_messages_list.pop(0)

                                logger.info(f"💬 [{message_counter}] {username}: {message}")

                                # ОТПРАВЛЯЕМ В ОВЕРЛЕЙ
                                if _socketio:
                                    try:
                                        _socketio.emit('new_message', message_data)
                                        logger.info(f"📤 Отправлено в оверлей: {username}: {message}")
                                    except Exception as e:
                                        logger.error(f"❌ Ошибка отправки: {e}")
                                else:
                                    logger.warning("⚠️ SocketIO не установлен!")

                                if len(seen_messages) > 1000:
                                    seen_messages.clear()

                            except Exception as e:
                                logger.error(f"❌ Ошибка обработки: {e}")
                    else:
                        if loop_count % 10 == 0:
                            logger.info("⏳ Сообщений нет")

                    try:
                        driver.execute_script("""
                            var scroller = document.querySelector('[data-a-target="chat-scroller"]');
                            if (scroller) scroller.scrollTop = scroller.scrollHeight;
                            var container = document.querySelector('[data-test-selector="chat-scrollable-area__message-container"]');
                            if (container) container.scrollTop = container.scrollHeight;
                        """)
                    except:
                        pass

                    time.sleep(parse_interval)

                except Exception as e:
                    logger.error(f"❌ Ошибка цикла: {e}")
                    time.sleep(3)

        except Exception as e:
            logger.error(f"❌ КРИТИЧЕСКАЯ ОШИБКА: {e}")
            import traceback
            logger.error(traceback.format_exc())
        finally:
            parsing_running = False
            remove_pid_file()
            logger.info("🛑 ПАРСИНГ ОСТАНОВЛЕН")

    thread = threading.Thread(target=run_parser, daemon=True)
    thread.start()
    logger.info("✅ ПОТОК ПАРСЕРА ЗАПУЩЕН")


def stop_parsing():
    global parsing_running, driver
    logger.info("🛑 Остановка парсинга...")
    parsing_running = False
    time.sleep(2)
    with driver_lock:
        if driver:
            try:
                driver.quit()
                driver = None
                logger.info("✅ Драйвер закрыт")
            except:
                pass
    remove_pid_file()
    logger.info("🛑 Парсинг остановлен")


def get_parsing_status():
    return {
        "running": parsing_running,
        "queue_size": message_queue.qsize(),
        "debug_messages": debug_messages_list[-5:]
    }


def get_message():
    try:
        return message_queue.get(timeout=1)
    except queue.Empty:
        return None