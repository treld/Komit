import tkinter as tk
from tkinter import ttk
import webbrowser
import threading
import webview
import sys
import os
import json




if __name__ == "__main__":
    app = OverlayWindow()
    app.run()