import threading
import queue
import time
import re
import logging
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager

logger = logging.getLogger(__name__)

message_queue = queue.Queue()
parsing_running = False
driver = None
driver_lock = threading.Lock()
_socketio = None
started_at = None
parser_thread = None
parse_interval = 3
debug_messages_list = []


def set_parse_interval(interval):
    global parse_interval
    if interval and interval > 0:
        parse_interval = interval
        logger.info(f"✅ Интервал парсинга: {parse_interval}с")


def set_socketio(socketio):
    global _socketio
    _socketio = socketio
    logger.info("✅ SocketIO установлен в парсер")


def init_driver():
    global driver
    with driver_lock:
        if driver is not None:
            return driver

        logger.info("🛠 Инициализация Chrome драйвера...")
        chrome_options = Options()

        # ВАЖНО: Включаем headless режим, чтобы скрыть окно браузера
        chrome_options.add_argument("--headless=new")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--window-size=1920,1080")
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option('useAutomationExtension', False)
        chrome_options.add_argument(
            "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

        # Скрываем логи Chrome
        chrome_options.add_argument("--log-level=3")
        chrome_options.add_experimental_option("excludeSwitches", ["enable-logging"])

        service = Service(ChromeDriverManager().install())
        service.creationflags = 0x08000000  # CREATE_NO_WINDOW в Windows

        driver = webdriver.Chrome(service=service, options=chrome_options)
        driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        logger.info("✅ Chrome драйвер инициализирован (headless режим)")
        return driver


def get_message_text(msg_element, username):
    try:
        js_script = """
            var element = arguments[0];
            var username = arguments[1];

            var fullText = element.textContent || element.innerText || '';
            var lines = fullText.split('\\n').map(function(line) { return line.trim(); });

            for (var i = 0; i < lines.length; i++) {
                var line = lines[i];
                if (line.includes('Время') || line.match(/^\\d{2}:\\d{2}/)) continue;
                if (!line) continue;
                return line;
            }

            return '';
        """
        text = driver.execute_script(js_script, msg_element, username)
        if text and text.strip():
            return text.strip()
    except Exception as e:
        logger.error(f"❌ Ошибка JS: {e}")
    return None


def clean_message(text, username):
    if not text:
        return ""
    pattern = re.compile(re.escape(username), re.IGNORECASE)
    cleaned = pattern.sub('', text).strip()
    if cleaned.startswith(':'):
        cleaned = cleaned[1:].strip()
    elif cleaned.startswith('：'):
        cleaned = cleaned[1:].strip()
    return cleaned.lstrip()


def get_user_avatar(msg_element):
    try:
        avatar_elem = msg_element.find_element(By.CSS_SELECTOR, "img[data-a-target='chat-avatar']")
        if avatar_elem:
            src = avatar_elem.get_attribute("src")
            if src:
                src = re.sub(r'-\d+x\d+\.', '-300x300.', src)
                return src
    except:
        pass
    try:
        avatar_elem = msg_element.find_element(By.CSS_SELECTOR, ".tw-avatar img")
        if avatar_elem:
            src = avatar_elem.get_attribute("src")
            if src:
                src = re.sub(r'-\d+x\d+\.', '-300x300.', src)
                return src
    except:
        pass
    return None


def start_parsing(channel, socketio=None):
    global parsing_running, _socketio, started_at, parser_thread

    if parsing_running:
        logger.warning("⚠️ Парсинг уже запущен")
        return False

    if not channel or not channel.strip():
        logger.error("❌ Канал не указан")
        return False

    if socketio:
        _socketio = socketio

    channel = channel.strip().lower()
    logger.info(f"🔄 Запуск парсинга для канала: {channel}")
    started_at = datetime.now().isoformat()

    def run_parser():
        global parsing_running, driver, debug_messages_list, _socketio

        try:
            driver = init_driver()

            url = f"https://www.twitch.tv/{channel}"
            logger.info(f"📡 Открываю страницу: {url}")
            driver.get(url)
            logger.info("⏳ Ожидание загрузки страницы...")
            time.sleep(5)
            logger.info("✅ Страница загружена")

            # Закрываем модальные окна
            try:
                close_btn = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.CSS_SELECTOR, "[data-a-target='modal-close-button']"))
                )
                close_btn.click()
                logger.info("✅ Модальное окно закрыто")
                time.sleep(1)
            except:
                pass

            # Принимаем cookies
            try:
                cookie_btn = driver.find_element(By.CSS_SELECTOR, "[data-a-target='consent-banner-accept']")
                cookie_btn.click()
                logger.info("✅ Cookie приняты")
                time.sleep(1)
            except:
                pass

            # Скроллим для загрузки чата
            driver.execute_script("window.scrollBy(0, 300);")
            time.sleep(2)

            logger.info(f"✅ Парсер запущен для канала {channel}")
            parsing_running = True

            if _socketio:
                try:
                    _socketio.emit('status_update', {'running': True, 'channel': channel})
                except:
                    pass

            seen_messages = set()
            message_counter = 0
            last_message_count = 0
            loop_count = 0
            current_interval = parse_interval

            while parsing_running:
                loop_count += 1
                try:
                    if loop_count % 10 == 0:
                        logger.info(f"🔄 Цикл {loop_count}, очередь: {message_queue.qsize()}")

                    messages = driver.find_elements(By.CSS_SELECTOR, "[data-a-target='chat-line-message']")

                    if messages:
                        if len(messages) != last_message_count:
                            logger.info(f"📊 Найдено сообщений: {len(messages)} (было: {last_message_count})")
                            last_message_count = len(messages)

                        for msg in messages:
                            try:
                                username = msg.get_attribute("data-a-user")
                                if not username:
                                    continue

                                raw_message = get_message_text(msg, username)
                                if not raw_message:
                                    continue

                                message = clean_message(raw_message, username)
                                if not message:
                                    continue

                                msg_id = f"{username}_{message}"
                                if msg_id in seen_messages:
                                    continue

                                timestamp = datetime.now().strftime("%H:%M")
                                try:
                                    aria_label = msg.get_attribute("aria-label")
                                    if aria_label:
                                        match = re.search(r"(\d{2}:\d{2})", aria_label)
                                        if match:
                                            timestamp = match.group(1)
                                except:
                                    pass

                                avatar = get_user_avatar(msg)

                                is_broadcaster = False
                                try:
                                    broadcaster_badges = msg.find_elements(By.CSS_SELECTOR,
                                                                           "img[alt='Владелец канала']")
                                    if broadcaster_badges:
                                        is_broadcaster = True
                                except:
                                    pass

                                message_data = {
                                    "username": username,
                                    "message": message,
                                    "timestamp": timestamp,
                                    "avatar": avatar,
                                    "is_broadcaster": is_broadcaster,
                                    "full_timestamp": datetime.now().isoformat()
                                }

                                message_queue.put(message_data)
                                seen_messages.add(msg_id)
                                message_counter += 1

                                debug_messages_list.append(message_data)
                                if len(debug_messages_list) > 50:
                                    debug_messages_list.pop(0)

                                logger.info(f"💬 [{message_counter}] {username}: {message}")

                                if _socketio:
                                    try:
                                        _socketio.emit('new_message', message_data)
                                    except:
                                        pass

                                if len(seen_messages) > 1000:
                                    seen_messages.clear()

                            except Exception as e:
                                logger.error(f"❌ Ошибка обработки сообщения: {e}")
                    else:
                        if loop_count % 10 == 0:
                            logger.info("⏳ Сообщений нет")

                    # Скроллим чат вниз
                    try:
                        driver.execute_script("""
                            var scroller = document.querySelector('[data-a-target="chat-scroller"]');
                            if (scroller) scroller.scrollTop = scroller.scrollHeight;
                            var container = document.querySelector('[data-test-selector="chat-scrollable-area__message-container"]');
                            if (container) container.scrollTop = container.scrollHeight;
                        """)
                    except:
                        pass

                    time.sleep(current_interval)

                except Exception as e:
                    logger.error(f"❌ Ошибка цикла: {e}")
                    time.sleep(3)

        except Exception as e:
            logger.error(f"❌ Критическая ошибка: {e}")
            import traceback
            logger.error(traceback.format_exc())
        finally:
            parsing_running = False
            if _socketio:
                try:
                    _socketio.emit('status_update', {'running': False})
                except:
                    pass
            logger.info("🛑 Парсинг остановлен")

    parser_thread = threading.Thread(target=run_parser, daemon=True)
    parser_thread.start()
    logger.info("✅ Поток парсера запущен")
    return True


def stop_parsing():
    global parsing_running, driver
    logger.info("🛑 Остановка парсинга...")
    parsing_running = False
    time.sleep(2)
    with driver_lock:
        if driver:
            try:
                driver.quit()
                driver = None
                logger.info("✅ Драйвер закрыт")
            except:
                pass
    logger.info("🛑 Парсинг остановлен")
    return True


def get_parsing_status():
    return {
        "running": parsing_running,
        "queue_size": message_queue.qsize(),
        "started_at": started_at,
        "debug_messages": debug_messages_list[-5:]
    }


def get_message():
    try:
        return message_queue.get(timeout=1)
    except queue.Empty:
        return None