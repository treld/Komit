from flask import Flask, render_template, request, jsonify, Response, send_from_directory
from flask_socketio import SocketIO, emit
import json
import logging
import os
import threading
import webbrowser
import sys
import time
import traceback
import queue

# Импортируем PyQt5 с защитой от ошибок
try:
    from PyQt5 import QtCore, QtWidgets, QtWebEngineWidgets, QtGui

    PYQT_AVAILABLE = True
except ImportError:
    PYQT_AVAILABLE = False
    print("⚠️ PyQt5 не установлен. Установите: pip install PyQt5 PyQtWebEngine")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'dev-secret-key'

# Используем threading вместо eventlet для стабильности
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

config = {}
running = True
qt_app = None
browser_window = None
flask_thread = None

# Импортируем парсер
try:
    import parser as twitch_parser

    PARSER_AVAILABLE = True
    logger.info("✅ Парсер загружен")
    twitch_parser.set_socketio(socketio)
except ImportError as e:
    PARSER_AVAILABLE = False
    logger.error(f"❌ Ошибка импорта парсера: {e}")


def load_config():
    global config
    try:
        with open('config.json', 'r', encoding='utf-8') as f:
            config = json.load(f)

        # Исправляем порт, если он пустой или строка
        if 'port' in config:
            try:
                if config['port'] == '' or config['port'] is None:
                    config['port'] = 8082
                else:
                    config['port'] = int(config['port'])
            except (ValueError, TypeError):
                config['port'] = 8082
        else:
            config['port'] = 8082

    except Exception as e:
        logger.error(f"Ошибка загрузки конфига: {e}")
        config = {
            'channel': '',
            'port': 8082,  # Всегда число!
            'messageDuration': 10,
            'maxMessages': 20,
            'autoRemove': True,
            'showBroadcaster': True,
            'bgOpacity': 0.85,
            'fontSize': 14,
            'parseInterval': 3,
            'customCSS': '''/* Ваши стили для сообщений */
.message {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 6px 10px;
    margin-bottom: 4px;
    border-radius: 6px;
    animation: slideIn 0.3s ease-out;
    background: rgba(255, 255, 255, 0.03);
    transition: all 0.2s;
}
.message:hover {
    background: rgba(255, 255, 255, 0.06);
}
.message-broadcaster {
    border-left: 2px solid #ffd700;
    background: rgba(255, 215, 0, 0.05);
}
.avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    flex-shrink: 0;
    border: 2px solid rgba(255, 255, 255, 0.05);
}
.avatar-placeholder {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    flex-shrink: 0;
    background: linear-gradient(135deg, #9147ff, #7c3aed);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: 600;
    font-size: 14px;
}
.content {
    flex: 1;
    min-width: 0;
}
.header {
    display: flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 1px;
}
.username {
    font-weight: 600;
    font-size: 13px;
    color: #9147ff;
}
.username.broadcaster {
    color: #ffd700;
}
.badge {
    font-size: 9px;
    padding: 1px 6px;
    border-radius: 10px;
    background: rgba(255, 215, 0, 0.15);
    color: #ffd700;
    font-weight: 600;
}
.time {
    font-size: 10px;
    color: #666;
    margin-left: auto;
}
.text {
    font-size: 13px;
    color: #e0e0e0;
    word-wrap: break-word;
    line-height: 1.3;
}
@keyframes slideIn {
    from {
        opacity: 0;
        transform: translateY(-10px) scale(0.98);
    }
    to {
        opacity: 1;
        transform: translateY(0) scale(1);
    }
}
.fade-out {
    opacity: 0;
    transform: translateX(-20px);
    transition: all 0.3s ease;
}'''
        }
        save_config()


def save_config():
    try:
        with open('config.json', 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
    except Exception as e:
        logger.error(f"Ошибка сохранения конфига: {e}")


load_config()


@app.route('/')
def dashboard():
    return render_template('dashboard.html', config=config)


@app.route('/overlay')
def overlay():
    return render_template('overlay.html', config=config)


@app.route('/api/config', methods=['GET', 'POST'])
def api_config():
    global config
    if request.method == 'GET':
        return jsonify(config)

    try:
        data = request.json
        if not data:
            return jsonify({'status': 'error', 'message': 'Нет данных'}), 400

        if 'channel' in data:
            channel = data['channel'].strip()
            if not channel:
                return jsonify({'status': 'error', 'message': 'Название канала не может быть пустым'}), 400
            data['channel'] = channel

        # Исправляем порт, если он передан
        if 'port' in data:
            try:
                if data['port'] == '' or data['port'] is None:
                    data['port'] = 8082
                else:
                    data['port'] = int(data['port'])
            except (ValueError, TypeError):
                data['port'] = 8082

        config.update(data)
        save_config()

        # Обновляем интервал в парсере
        if 'parseInterval' in data and PARSER_AVAILABLE:
            twitch_parser.set_parse_interval(data['parseInterval'])

        if 'channel' in data and PARSER_AVAILABLE:
            status = twitch_parser.get_parsing_status()
            if status['running']:
                twitch_parser.stop_parsing()
                time.sleep(1)
                if config.get('channel', '').strip():
                    twitch_parser.start_parsing(config.get('channel', ''))

        return jsonify({'status': 'ok'})
    except Exception as e:
        logger.error(f"Ошибка в api_config: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/status')
def api_status():
    try:
        if not PARSER_AVAILABLE:
            return jsonify({
                'running': False,
                'messages': 0,
                'channel': config.get('channel', ''),
                'error': 'Parser not available'
            })

        status = twitch_parser.get_parsing_status()
        return jsonify({
            'running': status['running'],
            'messages': status['queue_size'],
            'channel': config.get('channel', ''),
            'started_at': status.get('started_at'),
            'parse_interval': config.get('parseInterval', 3)
        })
    except Exception as e:
        logger.error(f"Ошибка в api_status: {e}")
        return jsonify({'running': False, 'messages': 0, 'channel': config.get('channel', ''), 'error': str(e)})


@app.route('/api/messages')
def api_messages():
    """Возвращает последние сообщения из очереди"""
    try:
        if not PARSER_AVAILABLE:
            return jsonify({'messages': []})

        messages = []
        temp_queue = []

        # Извлекаем все сообщения из очереди
        while not twitch_parser.message_queue.empty():
            try:
                msg = twitch_parser.message_queue.get_nowait()
                messages.append(msg)
                temp_queue.append(msg)
            except:
                break

        # Возвращаем сообщения обратно в очередь
        for msg in temp_queue:
            twitch_parser.message_queue.put(msg)

        return jsonify({'messages': messages[-50:]})
    except Exception as e:
        logger.error(f"Ошибка в api_messages: {e}")
        return jsonify({'messages': []})


@app.route('/api/start')
def api_start():
    try:
        if not PARSER_AVAILABLE:
            return jsonify({'status': 'error', 'message': 'Парсер не доступен'}), 500

        channel = config.get('channel', '').strip()

        if not channel:
            return jsonify({'status': 'error', 'message': 'Укажите название канала в настройках'}), 400

        if twitch_parser.get_parsing_status()['running']:
            return jsonify({'status': 'error', 'message': 'Парсер уже запущен'}), 400

        # Запускаем в отдельном потоке, чтобы не блокировать
        def start_in_thread():
            try:
                twitch_parser.start_parsing(channel)
            except Exception as e:
                logger.error(f"Ошибка запуска парсера: {e}")

        thread = threading.Thread(target=start_in_thread)
        thread.daemon = True
        thread.start()

        # Даем время на запуск
        time.sleep(1)

        return jsonify({'status': 'ok'})
    except Exception as e:
        logger.error(f"Ошибка в api_start: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/stop')
def api_stop():
    try:
        if not PARSER_AVAILABLE:
            return jsonify({'status': 'error', 'message': 'Парсер не доступен'}), 500

        if twitch_parser.get_parsing_status()['running']:
            twitch_parser.stop_parsing()
            return jsonify({'status': 'ok'})
        else:
            return jsonify({'status': 'error', 'message': 'Парсер не запущен'}), 400
    except Exception as e:
        logger.error(f"Ошибка в api_stop: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/stream')
def stream():
    """SSE поток для сообщений"""

    def generate():
        message_ids = set()
        while True:
            try:
                # Проверяем новые сообщения
                while not twitch_parser.message_queue.empty():
                    try:
                        msg = twitch_parser.message_queue.get_nowait()
                        if msg:
                            msg_id = f"{msg.get('username', '')}_{msg.get('message', '')}"
                            if msg_id not in message_ids:
                                message_ids.add(msg_id)
                                yield f"data: {json.dumps(msg)}\n\n"
                                if len(message_ids) > 1000:
                                    message_ids.clear()
                    except:
                        break

                # Keep-alive
                yield f"data: {json.dumps({'type': 'ping'})}\n\n"
                time.sleep(1)
            except GeneratorExit:
                break
            except Exception as e:
                logger.error(f"SSE ошибка: {e}")
                time.sleep(1)

    return Response(generate(), mimetype="text/event-stream")


@socketio.on('connect')
def handle_connect():
    logger.info('🔌 Клиент подключился к WebSocket')
    if PARSER_AVAILABLE:
        status = twitch_parser.get_parsing_status()
        emit('status_update', status)
        logger.info(f'📤 Отправлен статус: {status}')


@socketio.on('disconnect')
def handle_disconnect():
    logger.info('🔌 Клиент отключился от WebSocket')


@socketio.on('preview_opacity')
def handle_preview_opacity(opacity):
    emit('preview_opacity', opacity, broadcast=True)


def cleanup_processes():
    global running, qt_app
    logger.info("🧹 Начинаем очистку процессов...")
    running = False

    try:
        if PARSER_AVAILABLE:
            twitch_parser.stop_parsing()
            logger.info("✅ Парсер остановлен")
    except Exception as e:
        logger.error(f"Ошибка остановки парсера: {e}")

    try:
        if PYQT_AVAILABLE and qt_app:
            qt_app.quit()
            logger.info("✅ PyQt закрыт")
    except Exception as e:
        logger.error(f"Ошибка закрытия PyQt: {e}")

    logger.info("✅ Очистка завершена")


class BrowserWindow(QtWidgets.QMainWindow):
    def __init__(self, url, port, channel):
        super().__init__()
        self.url = url
        self.port = port
        self.channel = channel
        self.is_parsing = False
        self.init_ui()
        self.check_status()

    def init_ui(self):
        self.setWindowTitle(f"Twitch Chat Overlay - {self.channel if self.channel else 'Не выбран'}")
        self.setGeometry(100, 100, 500, 750)
        self.setMinimumSize(350, 500)

        self.setStyleSheet("""
            QMainWindow {
                background-color: #0d0d0d;
            }
            QToolBar {
                background-color: #1a1a1a;
                border: none;
                border-bottom: 1px solid #2a2a2a;
                padding: 5px;
                spacing: 5px;
            }
            QToolButton {
                background-color: transparent;
                color: #cccccc;
                font-size: 13px;
                padding: 5px 10px;
                border: none;
                border-radius: 4px;
                font-weight: 500;
            }
            QToolButton:hover {
                background-color: #2a2a2a;
                color: white;
            }
            QToolButton:pressed {
                background-color: #3a3a3a;
            }
            QToolButton:disabled {
                opacity: 0.5;
            }
            QLabel {
                color: #888888;
                font-size: 11px;
                padding: 5px;
            }
        """)

        self.toolbar = self.addToolBar("Navigation")
        self.toolbar.setMovable(False)

        self.create_toolbar_buttons()

        self.browser = QtWebEngineWidgets.QWebEngineView()
        self.browser.setUrl(QtCore.QUrl(self.url))

        settings = self.browser.settings()
        settings.setAttribute(QtWebEngineWidgets.QWebEngineSettings.JavascriptEnabled, True)
        settings.setAttribute(QtWebEngineWidgets.QWebEngineSettings.LocalStorageEnabled, True)
        settings.setAttribute(QtWebEngineWidgets.QWebEngineSettings.WebGLEnabled, True)

        self.browser.loadFinished.connect(self.on_load_finished)
        self.setCentralWidget(self.browser)

    def create_toolbar_buttons(self):
        dashboard_btn = QtWidgets.QToolButton()
        dashboard_btn.setText("Dashboard")
        dashboard_btn.setToolTip("Открыть панель управления")
        dashboard_btn.clicked.connect(self.open_dashboard)
        dashboard_btn.setStyleSheet("color: #9147ff;")
        self.toolbar.addWidget(dashboard_btn)

        self.toolbar.addSeparator()

        reload_btn = QtWidgets.QToolButton()
        reload_btn.setText("⟳")
        reload_btn.setToolTip("Перезагрузить оверлей")
        reload_btn.clicked.connect(self.reload_page)
        self.toolbar.addWidget(reload_btn)

        self.toolbar.addSeparator()

        port_label = QtWidgets.QLabel(f"Порт: {self.port}")
        self.toolbar.addWidget(port_label)

        spacer = QtWidgets.QWidget()
        spacer.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        self.toolbar.addWidget(spacer)

        self.status_label = QtWidgets.QLabel("○")
        self.status_label.setStyleSheet("color: #ff4444; font-size: 16px; font-weight: bold;")
        self.status_label.setToolTip("Парсер остановлен")
        self.toolbar.addWidget(self.status_label)

        self.toggle_btn = QtWidgets.QToolButton()
        self.toggle_btn.setText("▶ Запустить")
        self.toggle_btn.setToolTip("Запустить парсер")
        self.toggle_btn.clicked.connect(self.toggle_parser)
        self.toggle_btn.setStyleSheet("""
            QToolButton {
                background-color: #9147ff;
                color: white;
                font-weight: bold;
                padding: 5px 15px;
                border-radius: 4px;
            }
            QToolButton:hover:!disabled {
                background-color: #7c3aed;
            }
            QToolButton:disabled {
                background-color: #444;
                color: #888;
            }
        """)
        self.toolbar.addWidget(self.toggle_btn)

    def open_dashboard(self):
        webbrowser.open(f"http://localhost:{self.port}")

    def reload_page(self):
        self.browser.reload()

    def set_status(self, status, is_loading=False):
        if is_loading:
            self.status_label.setText("◐")
            self.status_label.setStyleSheet("color: #ffaa00; font-size: 16px; font-weight: bold;")
            self.status_label.setToolTip("Запуск парсера...")
            self.toggle_btn.setEnabled(False)
            self.toggle_btn.setText("⏳ Запуск...")
        elif status:
            self.status_label.setText("●")
            self.status_label.setStyleSheet("color: #00ff88; font-size: 16px; font-weight: bold;")
            self.status_label.setToolTip("Парсер запущен")
            self.toggle_btn.setEnabled(True)
            self.toggle_btn.setText("■ Остановить")
            self.toggle_btn.setToolTip("Остановить парсер")
            self.is_parsing = True
        else:
            self.status_label.setText("○")
            self.status_label.setStyleSheet("color: #ff4444; font-size: 16px; font-weight: bold;")
            self.status_label.setToolTip("Парсер остановлен")
            self.toggle_btn.setEnabled(True)
            self.toggle_btn.setText("▶ Запустить")
            self.toggle_btn.setToolTip("Запустить парсер")
            self.is_parsing = False

    def check_status(self):
        try:
            import urllib.request
            import json
            response = urllib.request.urlopen(f"http://localhost:{self.port}/api/status", timeout=3)
            if response.getcode() == 200:
                data = json.loads(response.read())
                self.set_status(data.get('running', False))
        except Exception as e:
            logger.error(f"Ошибка проверки статуса: {e}")
            self.set_status(False)

    def toggle_parser(self):
        try:
            import urllib.request
            import json

            if self.is_parsing:
                self.set_status(False, True)
                response = urllib.request.urlopen(f"http://localhost:{self.port}/api/stop", timeout=5)
                if response.getcode() == 200:
                    self.set_status(False)
                    self.check_status()
                else:
                    self.set_status(True)
            else:
                channel = self.channel
                if not channel:
                    self.set_status(False)
                    self.show_error("Укажите канал в настройках")
                    return

                self.set_status(False, True)
                response = urllib.request.urlopen(f"http://localhost:{self.port}/api/start", timeout=5)
                if response.getcode() == 200:
                    data = json.loads(response.read())
                    if data.get('status') == 'ok':
                        self.set_status(True)
                    else:
                        self.set_status(False)
                        self.show_error(data.get('message', 'Ошибка запуска'))
                else:
                    self.set_status(False)
                    self.show_error("Ошибка запуска парсера")
        except Exception as e:
            logger.error(f"Ошибка toggle_parser: {e}")
            self.set_status(False)
            self.show_error(str(e))

    def show_error(self, message):
        msg_box = QtWidgets.QMessageBox()
        msg_box.setIcon(QtWidgets.QMessageBox.Critical)
        msg_box.setWindowTitle("Ошибка")
        msg_box.setText(message)
        msg_box.setStyleSheet("""
            QMessageBox {
                background-color: #1a1a1a;
                color: #e0e0e0;
            }
            QPushButton {
                background-color: #9147ff;
                color: white;
                padding: 5px 15px;
                border: none;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #7c3aed;
            }
        """)
        msg_box.exec_()

    def on_load_finished(self, success):
        if success:
            self.check_status()

    def closeEvent(self, event):
        logger.info("🔄 Закрытие браузера...")
        cleanup_processes()
        event.accept()


class OverlayWindow:
    def __init__(self):
        # Исправляем получение порта
        port = config.get('port')
        try:
            if port == '' or port is None:
                self.port = 8082
            else:
                self.port = int(port)
        except (ValueError, TypeError):
            self.port = 8082

        self.channel = config.get('channel', '')

        if PYQT_AVAILABLE:
            self.run_pyqt()
        else:
            self.run_tkinter()

    def run_pyqt(self):
        global qt_app, browser_window

        # Проверяем, запущен ли сервер
        try:
            import urllib.request
            urllib.request.urlopen(f"http://localhost:{self.port}", timeout=2)
        except:
            logger.error("❌ Сервер не запущен!")
            self.run_tkinter()
            return

        qt_app = QtWidgets.QApplication.instance()
        if not qt_app:
            qt_app = QtWidgets.QApplication(sys.argv)

        url = f"http://localhost:{self.port}/overlay"
        browser_window = BrowserWindow(url, self.port, self.channel)
        browser_window.show()

        logger.info(f"✅ Оверлей загружен: {url}")

        try:
            qt_app.exec_()
        except Exception as e:
            logger.error(f"Ошибка PyQt: {e}")
        finally:
            cleanup_processes()

    def run_tkinter(self):
        import tkinter as tk
        from tkinter import ttk

        self.root = tk.Tk()
        self.root.title("Twitch Chat Overlay")
        self.root.geometry("500x400")
        self.root.configure(bg='#0d0d0d')
        self.root.resizable(False, False)

        title = tk.Label(
            self.root,
            text="Twitch Chat Overlay",
            font=('Segoe UI', 18, 'bold'),
            bg='#0d0d0d',
            fg='#9147ff'
        )
        title.pack(pady=20)

        info = tk.Label(
            self.root,
            text=f"Порт: {self.port}\nКанал: {self.channel or 'Не выбран'}",
            font=('Segoe UI', 10),
            bg='#0d0d0d',
            fg='#888888'
        )
        info.pack(pady=10)

        btn_frame = tk.Frame(self.root, bg='#0d0d0d')
        btn_frame.pack(pady=20)

        open_btn = tk.Button(
            btn_frame,
            text="Открыть оверлей в браузере",
            command=lambda: webbrowser.open(f"http://localhost:{self.port}/overlay"),
            bg='#9147ff',
            fg='white',
            font=('Segoe UI', 11, 'bold'),
            padx=20,
            pady=10,
            cursor='hand2',
            relief='flat',
            borderwidth=0
        )
        open_btn.pack(pady=5)

        dashboard_btn = tk.Button(
            btn_frame,
            text="Открыть панель управления",
            command=lambda: webbrowser.open(f"http://localhost:{self.port}"),
            bg='#2a2a2a',
            fg='white',
            font=('Segoe UI', 10),
            padx=20,
            pady=8,
            cursor='hand2',
            relief='flat',
            borderwidth=0
        )
        dashboard_btn.pack(pady=5)

        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.root.mainloop()

    def on_closing(self):
        cleanup_processes()
        try:
            os._exit(0)
        except:
            pass


def start_overlay_gui():
    OverlayWindow()


def run_flask():
    try:
        # Исправляем получение порта
        port = config.get('port')
        try:
            if port == '' or port is None:
                port = 8082
            else:
                port = int(port)
        except (ValueError, TypeError):
            port = 8082

        logger.info(f"🚀 Запуск Flask сервера на порту {port}")
        # ВАЖНО: Запускаем через eventlet
        try:
            # Пытаемся использовать eventlet
            socketio.run(app, host='0.0.0.0', port=port, debug=False, allow_unsafe_werkzeug=True)
        except Exception as e:
            logging.error(f"Ошибка запуска: {e}")
            # Альтернативный запуск
            app.run(host='0.0.0.0', port=port, debug=False, threaded=True)
    except Exception as e:
        logger.error(f"Flask error: {e}")


if __name__ == '__main__':
    # Исправляем получение порта
    port = config.get('port')
    try:
        if port == '' or port is None:
            port = 8082
        else:
            port = int(port)
    except (ValueError, TypeError):
        port = 8082

    logger.info(f'🚀 Server running on http://localhost:{port}')

    flask_thread = threading.Thread(target=run_flask, daemon=True)
    flask_thread.start()

    time.sleep(2)
    start_overlay_gui()